﻿using Exercise01;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise02
{
    class Program
    {
        static void Main(string[] args)
        {
            double number = 0;
            Console.Write("Enter a number");
            Console.WriteLine();
            string numStr = Console.ReadLine();
            bool isValid = double.TryParse(numStr, out number);
            if (!isValid)
            {
                Console.Write("Enter a valid number");
                Console.WriteLine();
            }
            else
            {
                string currentNum = numStr.Replace(",","");
                string numberInWords = currentNum.Trim().Towards();
                Console.Write("Number in words");
                Console.WriteLine();
                Console.Write(numberInWords);
                Console.WriteLine();
                Console.ReadKey();
            }
           
        }
        
    }
}
