﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeHierarchy.Model
{
    public class Employee
    {

        public string Id { get; set; }
        public string ManagerId { get; set; }
        public int Salary { get; set; }
        public override bool Equals(object obj)
        {
            Employee employee = (Employee)obj;
            return (employee.Id.ToUpper().Equals(Id.ToUpper()));
        }
    }
}
