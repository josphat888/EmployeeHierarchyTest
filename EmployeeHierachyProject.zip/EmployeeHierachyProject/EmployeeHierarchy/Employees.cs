﻿using EmployeeHierarchy.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeHierarchy
{
    public class Employees
    {
        private readonly Dictionary<string, List<string>> _employeeLstSubordinate = new Dictionary<string, List<string>>();
        public Dictionary<string, Employee> _employeeDict = new Dictionary<string, Employee>();

        public Employees(string[] empDetails)
        {
            if (empDetails.Any())
            {
                _employeeDict = GetEmployeesLst(empDetails);
                foreach (var employee in _employeeDict)
                {
                    Employee emp = employee.Value;
                    AddHierarchy(emp.ManagerId, emp.Id);
                }

            }
        }
        private Dictionary<string, Employee> GetEmployeesLst(string[] empArray)
        {
            Dictionary<string, Employee> employeesLst = new Dictionary<string, Employee>();
            int ceoCount = 0;
            foreach (var emp in empArray)
            {
                try
                {
                    var empData = emp.Split(',');
                    Employee currentEmp = new Employee();
                    currentEmp.Id = empData[0];
                    currentEmp.ManagerId = empData[1];
                    if (string.IsNullOrEmpty(currentEmp.Id))
                    {
                        Console.WriteLine("Employee Id must have a value");
                        employeesLst.Clear();
                        break;
                    }
                    if (string.IsNullOrEmpty(currentEmp.ManagerId) && ceoCount < 1)
                    {
                        ceoCount++;
                    }
                    else if (string.IsNullOrEmpty(currentEmp.ManagerId) && ceoCount == 1)
                    {
                        Console.WriteLine("There can only be one ceo in the organization");
                        employeesLst.Clear();
                        break;
                    }

                    int salary = 0;
                    bool validSalary = Int32.TryParse(empData[2], out salary);
                    if (validSalary)
                    {
                        if (salary > 0)
                        {
                            currentEmp.Salary = salary;

                            try
                            {
                                employeesLst.Add(currentEmp.Id, currentEmp);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Error when adding employee. Check for duplicates", ex);
                                employeesLst.Clear();
                                break;
                            }

                        }
                        else
                        {
                            Console.WriteLine("Salary must br greater than zero");
                            employeesLst.Clear();
                            break;
                        }



                    }
                    else
                    {
                        Console.WriteLine("Salary is not valido");
                        employeesLst.Clear();
                        break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }

            }
            if (ceoCount != 1)
            {
                Console.WriteLine("There is no CEO in the current dataset");
                employeesLst.Clear();
            }


            return employeesLst;
        }

        public long GetTotalSalary(string managerId)
        {
            long salary = 0;
            HashSet<String> traversed = new HashSet<String>();
            Stack<String> empstack = new Stack<String>();
            empstack.Push(managerId);
            while (empstack.Count != 0)
            {
                String empId = empstack.Pop();
                if (!traversed.Contains(empId))
                {
                    traversed.Add(empId);
                    foreach (string item in GetManagerSurbodinates(empId))
                    {
                        empstack.Push(item);
                    }
                }
            }

            if (traversed.Count == 0) return salary;
            foreach (var id in traversed)
            {
                var emp = GetEmployee(id);
                salary += emp != null ? emp.Salary : 0;
            }

            return salary;

        }
        //Get list of employees who reports to a given manager 
        public List<String> GetManagerSurbodinates(string Id)
        {
            return _employeeLstSubordinate[Id];
        }
        public Dictionary<string, List<string>> GetSurbodinateLst()
        {
            return _employeeLstSubordinate;
        }
        //get employee given the Id
        public Employee GetEmployee(string Id)
        {
            Employee employee = null;
            try
            {
                if (_employeeDict.ContainsKey(Id))
                {
                    employee = _employeeDict[Id];
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"There is no employee with Id {Id}");
                return employee;
            }
            return employee;
        }
        public void AddEmp(string empId)
        {
            if (!_employeeLstSubordinate.ContainsKey(empId))
            {
                _employeeLstSubordinate.Add(empId, new List<string>());
            }
        }
        public void AddHierarchy(string managerId, string emId)
        {
            AddEmp(managerId);
            AddEmp(emId);
            _employeeLstSubordinate[managerId].Add(emId);
        }
    }
}
