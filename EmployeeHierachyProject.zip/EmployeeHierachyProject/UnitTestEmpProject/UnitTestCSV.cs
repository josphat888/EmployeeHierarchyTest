﻿using EmployeeHierarchy;
using EmployeeHierarchy.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;

namespace UnitTestEmpProject
{
    [TestClass]
    public class UnitTestCSV
    {
        private Employees _hierarchy;

        [TestInitialize]
        public void InitiliazeData()
        {
            var Path = AppDomain.CurrentDomain.BaseDirectory + "\\data\\InitialTest.csv";
            var data = GetData(Path);
            _hierarchy = new Employees(data);
        }
        // Tests if the GetEmployee returns a Employee object given a valid ID
        [TestMethod]
        public void GetEmployee()
        {
            Employee emp = _hierarchy.GetEmployee("Employee1");
            Assert.IsNotNull(emp);
        }
        //Test if employess are added to graph
        [TestMethod]
        public void EmployeesAddedTest()
        {
            Assert.IsTrue(_hierarchy._employeeDict.ContainsValue(new Employee
            { Id = "Employee4", ManagerId = "Employee2", Salary = 800 }));
            Assert.IsTrue(_hierarchy._employeeDict.ContainsValue(new Employee
            { Id = "Employee3", ManagerId = "Employee1", Salary = 500 }));

        }
        [TestMethod]
        public void GetBudgetTest()
        {
            var Path = AppDomain.CurrentDomain.BaseDirectory + "\\data\\BudgetTest.csv";
            Employees hierarchy = new Employees(GetData(Path));
            Assert.AreEqual(3800, hierarchy.GetTotalSalary("Employee1"));
            Assert.AreEqual(1800, hierarchy.GetTotalSalary("Employee2"));
            Assert.AreEqual(500, hierarchy.GetTotalSalary("Employee3"));
        }

        //test graph child parent relationship
        
        [TestMethod]
        public void ManagerHasSurbodiantesTest()
        {
            var subordinates = _hierarchy.GetManagerSurbodinates("Employee2");
            Assert.AreEqual(2, subordinates.Count);
        }
        //Only one CEO in the organization test.
        [TestMethod]
        public void MoreThanOneCEOTest()
        {
            var Path = AppDomain.CurrentDomain.BaseDirectory + "\\data\\OneCEOTest.csv";
            Employees hierarchy = new Employees(GetData(Path));
            Assert.IsFalse(hierarchy._employeeDict.ContainsKey("Employee5"));
            Assert.IsFalse(hierarchy._employeeDict.ContainsKey("Employee1"));
            Assert.AreEqual(0, hierarchy._employeeDict.Count);

        }

        //validate salary
        [TestMethod]
        public void InvalidSalaryCheck()
        {
            var Path = AppDomain.CurrentDomain.BaseDirectory + "\\data\\InvalidSalaryTest.csv";
            Employees hierarchy = new Employees(GetData(Path));
            Assert.IsFalse(hierarchy._employeeDict.ContainsKey("Employee2"));
            Assert.AreEqual(0, hierarchy._employeeDict.Count);
        }
        
        //No CEO/Manager in the organization test
        [TestMethod]
        public void NoCEORecordTest()
        {
            var Path = AppDomain.CurrentDomain.BaseDirectory + "\\data\\CeoRecordTest.csv";
            Employees h = new Employees(GetData(Path));
            Assert.AreEqual(0, h._employeeDict.Count);
        }
        string[] GetData(String path)
        {

            return File.ReadAllLines(path);
        }
    }
}
